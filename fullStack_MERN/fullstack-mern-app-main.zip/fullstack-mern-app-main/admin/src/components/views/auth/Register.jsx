import React from "react";

const Register = () => {
  return (
    <div>
      <h5>Register</h5>
    </div>
  );
};

export default Register;
