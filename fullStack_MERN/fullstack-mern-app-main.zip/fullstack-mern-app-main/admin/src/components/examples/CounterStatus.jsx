import React from "react";
const CounterSrtatus = (props) => {
  return <div>Current Value of COunter is {props.count}</div>;
};

export default CounterSrtatus;
